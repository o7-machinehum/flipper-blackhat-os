package main

import (
    "fmt"
    "os"
)

func main() {
    fmt.Println("RAT started... (this is a placeholder)")
    // TODO: Implement functionality
    if len(os.Args) > 1 {
        fmt.Println("Running with arg:", os.Args[1])
    }
}
