# RAT Protocol Implementation

This repo contains the prototype implementation of a Go-based RAT for Flipper Blackhat OS.

## 🛠 Build Instructions

To build the binary:

```bash
./build.sh
```

This will create a lightweight `rat` binary suitable for deployment on Blackhat OS.

## 📦 Why precompiled?

- Keeps Blackhat image lean
- No need to install Go on target
- Runs fast and reliably from SD or userfs

## ⚙️ Config Sample

See `config_sample.json` for a starter config file.
