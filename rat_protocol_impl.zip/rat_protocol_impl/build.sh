#!/bin/bash
GOOS=linux GOARCH=arm go build -o rat payload/rat.go
echo "✅ Built: ./rat"
